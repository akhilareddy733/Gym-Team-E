import { Component } from '@angular/core';

@Component({
  selector: 'app-deitplan-details',
  templateUrl: './deitplan-details.component.html',
  styleUrls: ['./deitplan-details.component.css']
})
export class DeitplanDetailsComponent {

}
